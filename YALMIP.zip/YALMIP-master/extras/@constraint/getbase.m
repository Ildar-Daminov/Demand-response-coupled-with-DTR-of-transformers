function B = getbase(F)

B = getbase(lmi(F));